Simple calculator for Android
Calculates basic math operations Plus, Minus, Multiply, Division. Supports negative numbers as first, second and both arguments. Like -X+Y, X+(-Y), -X*(-Y). 

Known bug: crashes if no number was entered, but button Minus was pressed two times